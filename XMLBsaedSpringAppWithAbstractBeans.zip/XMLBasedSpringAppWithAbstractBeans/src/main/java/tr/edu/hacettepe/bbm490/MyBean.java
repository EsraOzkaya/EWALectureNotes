package tr.edu.hacettepe.bbm490;

public class MyBean {

	private String uberMessage;
	private String message;

	public void setMessage(String message) {
		this.message = message;
	}
	
	public void setUberMessage(String uberMessage) {
		this.uberMessage = uberMessage;
	}

	public void printMessage() {
		System.out.println("Greeting " + message + " with uber message: " + uberMessage);
	}
}