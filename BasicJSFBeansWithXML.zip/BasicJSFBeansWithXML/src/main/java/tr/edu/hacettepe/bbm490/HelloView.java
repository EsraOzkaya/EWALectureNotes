package tr.edu.hacettepe.bbm490;

public class HelloView {

	private String helloMessage = "Greetings all!";

	public String getMessage() {
		return helloMessage;
	}
}


