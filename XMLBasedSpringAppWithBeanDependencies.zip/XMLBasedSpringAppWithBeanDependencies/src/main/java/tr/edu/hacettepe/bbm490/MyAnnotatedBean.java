package tr.edu.hacettepe.bbm490;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MyAnnotatedBean {

	@Autowired
	private MyDependencyBean bean;
	
	public void printMessage() {
		bean.echo();
	}
}
