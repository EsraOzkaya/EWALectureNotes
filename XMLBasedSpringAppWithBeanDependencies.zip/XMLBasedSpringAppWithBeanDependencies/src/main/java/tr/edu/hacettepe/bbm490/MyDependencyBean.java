package tr.edu.hacettepe.bbm490;

import org.springframework.stereotype.Component;

@Component
public class MyDependencyBean {

	public void echo() {
		System.out.println("Hi..!");
	}
}
