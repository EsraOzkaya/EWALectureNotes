package tr.edu.hacettepe.bbm490;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Test {

	public static void main(String args[]) throws SQLException   {
		Driver myDriver = new com.mysql.jdbc.Driver();
		DriverManager.registerDriver( myDriver );
		String url = "jdbc:mysql://127.0.0.1:3306/bbm490";
		
		Connection conn = DriverManager.getConnection(url, "root", "");
		try {
			Statement stmt = conn.createStatement();

			String SQL = "INSERT INTO Users VALUES ('003', 'Mike', 'Johnson', 'bird', 1)";
			stmt.executeUpdate(SQL);

			SQL = "INSERT IN Users VALUES ('004', 'John', 'Nash', 'duck', 0)";
			stmt.executeUpdate(SQL);
			// If there is no error.
			conn.commit();
		} catch (SQLException se) {
			System.out.println(se);
			// If there is any error.
			conn.rollback();
		}
	}
}
