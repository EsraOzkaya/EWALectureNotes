package tr.edu.hacettepe.bbm490.bean;

import org.springframework.stereotype.Component;

@Component
public class MyBean {

    public void sayHello() {
        System.out.println("Hello..!");
    }
}
