package tr.edu.hacettepe.bbm490;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import tr.edu.hacettepe.bbm490.MyBean;

public class Application {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
 
		MyBean obj = (MyBean) context.getBean("myBean");
		obj.printMessage();
		
		((ConfigurableApplicationContext) context).close();
	}
}
