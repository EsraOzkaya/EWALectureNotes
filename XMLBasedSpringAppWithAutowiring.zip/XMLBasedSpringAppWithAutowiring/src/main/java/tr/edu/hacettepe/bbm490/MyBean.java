package tr.edu.hacettepe.bbm490;

public class MyBean {

	private String message;
	
	private MyDependencyBean bean;

	public void setBean(MyDependencyBean bean) {
		this.bean = bean;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public void printMessage() {
		System.out.println("Greeting " + message);
		bean.printMessage();
	}
}