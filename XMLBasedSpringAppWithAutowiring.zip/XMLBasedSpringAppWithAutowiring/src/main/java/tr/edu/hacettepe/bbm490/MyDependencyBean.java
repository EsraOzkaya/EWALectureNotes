package tr.edu.hacettepe.bbm490;

public class MyDependencyBean {

	public void printMessage() {
		System.out.println("MyDependencyBean Greeting");
	}
}