package tr.edu.hacettepe.bbm490;

import org.springframework.stereotype.Component;

@Component
public class MyBean {

	public MyBean() {
		System.out.println("Constructed");
	}
}
