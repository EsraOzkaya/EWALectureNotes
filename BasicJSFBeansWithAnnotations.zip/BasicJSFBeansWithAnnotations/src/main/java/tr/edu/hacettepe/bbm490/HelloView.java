package tr.edu.hacettepe.bbm490;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class HelloView implements Serializable {

	public HelloView() {
		System.out.println("constructed");
	}
	
	private String helloMessage = "Greetings all!";

	public String getMessage() {
		return helloMessage;
	}
}



