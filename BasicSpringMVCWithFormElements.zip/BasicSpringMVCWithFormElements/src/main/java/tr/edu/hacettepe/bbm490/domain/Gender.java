package tr.edu.hacettepe.bbm490.domain;

public enum Gender {
	MALE,
	FEMALE;
}
