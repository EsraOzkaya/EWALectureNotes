package tr.edu.hacettepe.bbm490;

import java.io.Serializable;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class CountryView implements Serializable {

	@ManagedProperty(value = "#{countryService}")
	private CountryService countryService;
	
	public List<Country> getCountries() {
		return countryService.getCountries();
	}

	public void setCountryService(CountryService countryService) {
		this.countryService = countryService;
	}
}
