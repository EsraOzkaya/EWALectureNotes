package tr.edu.hacettepe.bbm490;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

@ManagedBean(name="countryService")
@ApplicationScoped
public class CountryServiceImpl implements CountryService {

	List<Country> countries = new ArrayList<Country>();
	
	@PostConstruct
	public void setup() {
		countries.add(new Country(1, "Turkey", 75000000l));
		countries.add(new Country(2,"USA", 350000000l));
		countries.add(new Country(3, "Germany", 100000000l));
	}
	
	public List<Country> getCountries() {
		return countries;
	}
}
