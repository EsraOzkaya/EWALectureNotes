package tr.edu.hacettepe.bbm490;

import java.util.List;

public interface CountryService {
	
	List<Country> getCountries();
}
